using System;

class Program
{
    static void Main()
    {
        Console.Title = "Cybersecurity Awareness Bot - South Africa";
        var bot = new Chatbot();
        bot.Start();
        Console.ResetColor();
        Console.WriteLine("\nPress any key to exit...");
        Console.ReadKey();
    }
}