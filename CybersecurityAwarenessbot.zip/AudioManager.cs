using System;
using System.Media;
using System.IO;

public class AudioManager
{
    public static void PlayWelcomeGreeting()
    {
        try
        {
            string audioPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "welcome_greeting.wav");

            if (File.Exists(audioPath))
            {
                using (SoundPlayer player = new SoundPlayer(audioPath))
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("🎵 Playing welcome voice message...");
                    Console.ResetColor();
                    player.PlaySync();  // Plays and waits until finished
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("⚠️  Audio file not found. Skipping voice greeting.");
                Console.ResetColor();
            }
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"⚠️  Could not play audio: {ex.Message}");
            Console.ResetColor();
        }
    }
}