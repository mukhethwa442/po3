using System;

public static class AsciiArt
{
    public static void DisplayLogo()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
   _____      _          _____                           _                 
  / ____|    | |        / ____|                         | |                
 | |     _   _| |__   _| (___   ___ _ __ ___  ___ _ __ | |_ _   _ _ __ ___ 
 | |    | | | | '_ \ | |\___ \ / _ \ '__/ __|/ _ \ '_ \| __| | | | '__/ _ \
 | |____| |_| | |_) || |____) |  __/ |  \__ \  __/ | | | |_| |_| | | |  __/
  \_____|\__,_|_.__/ | |_____/ \___|_|  |___/\___|_| |_|\__|\__,_|_|  \___|
                    _/ |                                                   
                   |__/                                                    
        South African Cybersecurity Awareness Bot
");
        Console.ResetColor();
        Console.WriteLine("".PadRight(80, '=') + "\n");
    }
}