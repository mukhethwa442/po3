using System;
using System.Threading;

public class Chatbot
{
    private string userName = "Friend";

    public void Start()
    {
        // Voice Greeting + ASCII Logo
        AudioManager.PlayWelcomeGreeting();
        AsciiArt.DisplayLogo();

        // Text Greeting
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine("Hello! Welcome to the **Cybersecurity Awareness Bot** 🇿🇦\n");
        Console.Write("Please enter your name: ");
        userName = Console.ReadLine()?.Trim() ?? "Friend";

        if (string.IsNullOrWhiteSpace(userName))
            userName = "Cyber Warrior";

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"\n👋 Welcome, {userName}! I'm here to help you stay safe online.\n");
        Console.ResetColor();

        ShowHelp();
        RunConversation();
    }

    private void ShowHelp()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("You can ask me about:");
        Console.WriteLine("   • How are you?");
        Console.WriteLine("   • What is your purpose?");
        Console.WriteLine("   • Password safety / strong passwords");
        Console.WriteLine("   • Phishing / phishing emails");
        Console.WriteLine("   • Safe browsing / suspicious links");
        Console.WriteLine("   • help / exit\n");
        Console.ResetColor();
    }

    private void RunConversation()
    {
        Console.WriteLine("Type your questions below (type 'exit' to quit)\n".PadRight(60, '-'));

        while (true)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($"\n{userName}: ");
            string input = Console.ReadLine()?.Trim() ?? "";

            if (string.IsNullOrWhiteSpace(input))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("🤖 I didn't quite understand that. Could you rephrase?");
                continue;
            }

            if (input.ToLower() == "exit" || input.ToLower() == "quit")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\nThank you, {userName}! Stay safe online. 🇿🇦");
                break;
            }

            ProcessInput(input);
        }
    }

    private void ProcessInput(string input)
    {
        string lowerInput = input.ToLower();

        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write("🤖 CyberBot: ");

        if (lowerInput.Contains("how are you") || lowerInput.Contains("how r u"))
        {
            Console.WriteLine("I'm doing great, thank you! Always ready to help South Africans stay cyber safe! 🔥");
        }
        else if (lowerInput.Contains("purpose") || lowerInput.Contains("who are you"))
        {
            Console.WriteLine("My purpose is to educate South African citizens about cybersecurity threats like phishing, malware, and social engineering.");
        }
        else if (lowerInput.Contains("password") || lowerInput.Contains("passwords"))
        {
            Console.WriteLine("✅ Use strong, unique passwords! Combine uppercase, lowercase, numbers & symbols.\n" +
                              "   Never reuse the same password across sites. Consider using a password manager.");
        }
        else if (lowerInput.Contains("phishing"))
        {
            Console.WriteLine("🚨 Phishing emails often create urgency or fear.\n" +
                              "   Never click links or download attachments from unknown senders.\n" +
                              "   Check the email address carefully – scammers spoof legitimate ones.");
        }
        else if (lowerInput.Contains("link") || lowerInput.Contains("links") || lowerInput.Contains("safe browsing"))
        {
            Console.WriteLine("⚠️  Hover over links before clicking to see the real URL.\n" +
                              "   Avoid clicking shortened links (bit.ly, t.co) from unknown sources.\n" +
                              "   Use HTTPS websites only when entering personal information.");
        }
        else if (lowerInput.Contains("help"))
        {
            ShowHelp();
            return;
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Sorry, I didn't understand that. Try asking about passwords, phishing, or safe browsing.");
        }

        Console.ResetColor();
        
        // Small typing delay for better UX
        Thread.Sleep(400);
    }
}